package co.ceiba.parking.controller;

import org.springframework.stereotype.Controller;

@Controller
public class VehiculoController {

}
