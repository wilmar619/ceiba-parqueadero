package co.ceiba.parking.repository;

import org.springframework.stereotype.Repository;

@Repository
public class ParkingRepository {

}
