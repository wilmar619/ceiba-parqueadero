package co.ceiba.parking.modelo.service;

public interface InterfaceVehiculo {

	public String validarTipo();

	public String verificarPlaca(String dia);

	public int valorAdicionalCilindraje();


}
